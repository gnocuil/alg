#include <iostream>
#include <cstdio>
#include <string>
#include <cstring>
#include <arpa/inet.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <sstream>
#include <time.h>
//#include "ftp.h"
#include "../../ip.h"
//#include "ftp_srv.h"

using namespace std;

const int TESTS = 10;
const int REPEAT_TIMES = 100;

static long long gettime(struct timeval t1, struct timeval t2) {
    return (t2.tv_sec - t1.tv_sec) * 1000000 + (t2.tv_usec - t1.tv_usec) ;
}

class SIPTests {
public:
    SIPTests(std::string my_ip_, std::string server_ip_, int id_) {
        my_ip = my_ip_;
        srv_ip = server_ip_;
        id = id_;
        
        fd = socket(PF_INET6, SOCK_DGRAM, 0);
        
        struct sockaddr_in6 addr;
        memset((char *) &addr, 0, sizeof(addr));
        addr.sin6_family = AF_INET6;
        addr.sin6_port = htons(5060);
        addr.sin6_addr = in6addr_any;
        int status;
        if ( (status = bind(fd, (struct sockaddr *) &addr, sizeof(addr))) < 0)
            printf("bind error with port %s\n", strerror(errno));  
            
        memset((char *) &srv_addr, 0, sizeof(srv_addr));
        srv_addr.sin6_family = AF_INET6;
        srv_addr.sin6_port = htons(5060);
        inet_pton(AF_INET6, srv_ip.c_str(),&srv_addr.sin6_addr);  
        
        totalbytes = 0;
    }
    void send_invite(int id2) {
        ostringstream buf;
        buf << "INVITE sip:service@[" << srv_ip << "]:5060 SIP/2.0\r\n";
        buf << "Via: SIP/2.0/UDP [" << my_ip << "]:5060;branch=z9hG4bK-4872-1-0\r\n";
        buf << "From: sipp <sip:sipp@[" << my_ip << "]:5060>;tag=4872SIPpTag001\r\n";
        buf << "To: service <sip:service@[" << srv_ip << "]:5060>\r\n";
        buf << "Call-ID: " << id << "-" << id2 << "@" << my_ip << "\r\n";
        buf << "CSeq: 1 INVITE\r\n";
        buf << "Contact: sip:sipp@[" << my_ip << "]:5060\r\n";
        buf << "Max-Forwards: 70\r\n";
        buf << "Subject: Performance Test\r\n";
        buf << "Content-Type: application/sdp\r\n";
        
        ostringstream buf2;
        buf2 << "v=0\r\n";
        buf2 << "o=user1 53655765 2353687637 IN IP6 [" << my_ip << "]\r\n";
        buf2 << "s=-\r\n";
        buf2 << "c=IN IP6 " << my_ip << "\r\n";
        buf2 << "t=0 0\r\n";
        buf2 << "m=audio 6000 RTP/AVP 0\r\n";
        buf2 << "a=rtpmap:0 PCMU/8000\r\n";
        
        buf << "Content-Length:  " << buf2.str().size() << "\r\n";
        buf << "\r\n";
        
        buf << buf2.str();
        
        send(buf.str());

    }
    
    void send_ack() {
        ostringstream buf;
        buf << "ACK sip:service@[" << srv_ip << "]:5060 SIP/2.0\r\n";
        buf << "Via: SIP/2.0/UDP [" << my_ip << "]:5060;branch=z9hG4bK-4872-1-0\r\n";
        buf << "From: sipp <sip:sipp@[" << my_ip << "]:5060>;tag=4872SIPpTag001\r\n";
        buf << "To: service <sip:service@[" << srv_ip << "]:5060>\r\n";
        buf << "Call-ID: " << callid << "\r\n";
        buf << "CSeq: 1 ACK\r\n";
        buf << "Contact: sip:sipp@[" << my_ip << "]:5060\r\n";
        buf << "Max-Forwards: 70\r\n";
        buf << "Subject: Performance Test\r\n";
        buf << "Content-Type: application/sdp\r\n";
        
        buf << "Content-Length:  " <<0 << "\r\n";
        buf << "\r\n";
        
        send(buf.str());

    }
    
    void send_bye() {
        ostringstream buf;
        buf << "BYE sip:service@[" << srv_ip << "]:5060 SIP/2.0\r\n";
        buf << "Via: SIP/2.0/UDP [" << my_ip << "]:5060;branch=z9hG4bK-4872-1-0\r\n";
        buf << "From: sipp <sip:sipp@[" << my_ip << "]:5060>;tag=4872SIPpTag001\r\n";
        buf << "To: service <sip:service@[" << srv_ip << "]:5060>\r\n";
        buf << "Call-ID: " << callid << "\r\n";
        buf << "CSeq: 2 BYE\r\n";
        buf << "Contact: sip:sipp@[" << my_ip << "]:5060\r\n";
        buf << "Max-Forwards: 70\r\n";
        buf << "Subject: Performance Test\r\n";
        buf << "Content-Type: application/sdp\r\n";
        
        buf << "Content-Length:  " <<0 << "\r\n";
        buf << "\r\n";
        
        send(buf.str());

    }
    
    void send(std::string buf) {
        sendto(fd, buf.c_str(), buf.size(), 0, (struct sockaddr *)&srv_addr, sizeof(srv_addr));
        totalbytes += buf.size();
    }
    
    int recv() {
        char buf[2000];
        int len = recvfrom(fd, buf, sizeof(buf), 0, 0, 0);
        if (len <= 0) return -1;
        totalbytes += len;
        istringstream sin(buf);
        string tmp;
        sin >> tmp;
        int code;
        sin >> code;
        //printf("code=%d\n", code);
        while (sin >> tmp) {
            if (tmp == "Call-ID:") {
                sin >> callid;
                //cout << "callid="<<callid<<endl;
            }
            if (tmp == "CSeq:") {
                sin >> tmp >> cseq;
                //cout << "cseq="<<cseq<<endl;
            }
        }
        return code;
    }
    void run() {
        for (int i = 0; i < TESTS; ++i) {
            send_invite(1000+i+1);
        }
        int cnt_180 = 0;
        int cnt_200 = 0;
        do {
            int code = recv();
            switch (code) {
            case 180:
                ++cnt_180;
                break;
            case 200:
                ++cnt_200;
                if (cseq == "INVITE") {
                    send_ack();
                    send_bye();
                }
            default:
                break;
            }
            if (cnt_180 == TESTS && cnt_200 == TESTS*2) break;
        } while (1);
        close(fd);
    }
//private:
    std::string my_ip;
    std::string srv_ip;
    int id;
    int fd;
    struct sockaddr_in6 srv_addr;
    string callid;
    string cseq;
    
    int totalbytes;
};



int main(int argc, char **argv)
{
    //FTPServer srv;
    if (argc > 2) {
        printf("from %s to %s\n", argv[1], argv[2]);
        char src[100];
        char dst[100];
        strcpy(src, argv[1]);
        
        if (inet_pton(AF_INET6, argv[2], dst) == 1) {//to v6
            SIPTests* tests[REPEAT_TIMES];
            
            struct timeval t1, t2;
            gettimeofday(&t1, NULL);
            
            for (int i = 0; i < REPEAT_TIMES; ++i) {
                tests[i] = new SIPTests(argv[1], argv[2], i + 1);
                tests[i]->run();
            }
            
            gettimeofday(&t2, NULL);

            int totalbytes = 0;
            for (int i = 0; i < REPEAT_TIMES; ++i) {
                totalbytes += tests[i]->totalbytes;
            }
            
            cout << "totalbytes(bytes)=" << tests[0]->totalbytes * REPEAT_TIMES << endl;
            cout << "totaltime(ms)=" << gettime(t1, t2) / 1000.0 << endl;
            cout << "Request per second=" << REPEAT_TIMES * TESTS / (gettime(t1, t2) / 1000000.0) << endl;
            cout << "Rate(kbps)=" << totalbytes * 8 / 1000.0 / (gettime(t1, t2) / 1000000.0) << endl;
            
            
//        } else if (inet_pton(AF_INET, argv[1], dst) == 1) {
//            puts("to v4");
        } else {
            return 0;
        }
/*
            //srv.run();
            struct timeval t1, t2;
            gettimeofday(&t1, NULL);
            FTPTests* tests[REPEAT_TIMES];
            for (int i = 0; i < REPEAT_TIMES; ++i) {
                tests[i] = new FTPTests(argv[1]);
                tests[i]->run();
                //sleep(1);
            }
            gettimeofday(&t2, NULL);
            long long totalbytes = 0;
            long long time_eprt = 0;
            long long time_pwd = 0;
            for (int i = 0; i < REPEAT_TIMES; ++i) {
                totalbytes += tests[i]->recvbytes;
                time_eprt += tests[i]->time_eprt;
                time_pwd += tests[i]->time_pwd;
                //cout << "#" << i << "\t" << tests[i]->time_total << "\t" << tests[i]->recv_KBps << "\t" << tests[i]->time_eprt << "\t" << tests[i]->time_pwd << endl;
            }
            
            cout << "totalbytes(bytes)=" << totalbytes << " " << tests[0]->bytes << endl;
            cout << "totaltime(ms)=" << gettime(t1, t2) / 1000.0 << endl;
            cout << "Request per second=" << REPEAT_TIMES / (gettime(t1, t2) / 1000000.0) << endl;
            cout << "Rate(KBps)=" << totalbytes / 1000.0 / (gettime(t1, t2) / 1000000.0) << endl;
            cout << "EPRT RTT(ms)=" << (double)time_eprt / REPEAT_TIMES / TESTS / 1000.0 << endl;
            cout << "PWD RTT(ms)=" << (double)time_pwd / REPEAT_TIMES / TESTS / 1000.0 << endl;
          
        } else if (inet_pton(AF_INET, argv[1], tmp) == 1) {
            puts("IPv4 addr! quit...");
            return 0;
        } else {
            puts("invalid addr! quit...");
            return 0;
        }
        */
    }
//    for (int i = 0; i < srv.son.size(); ++i)
//        kill(srv.son[i], SIGKILL);
//    exit(0);
}
