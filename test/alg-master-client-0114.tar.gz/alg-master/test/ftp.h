#pragma once
#include <iostream>
#include <cstdio>
#include <string>
#include <cstring>
#include <arpa/inet.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>

#include "../ip.h"

using namespace std;

const bool active = false;
const int BUF_LEN = 100000;
const bool DATA = true;
const string SIZE = "1000";

static long long gettime(struct timeval t1, struct timeval t2) {
    return (t2.tv_sec - t1.tv_sec) * 1000000 + (t2.tv_usec - t1.tv_usec) ;
}

class FTPTest {
public:
    FTPTest(std::string server_ip)
        : serverip(server_ip),
          t2(0),
          done(false),
          sendbytes(0),
          recvbytes(0) {
    }
    void run() {
        int ret = pthread_create(&tid, NULL, _thread_t, this);
    }
    static void* _thread_t(void* param) {
        FTPTest* test = (FTPTest*)param;
        test->run__();
        return NULL;
    }
    void Send(const std::string& str) {
        sendbytes += str.size();
        send(fd, str.c_str(), str.size(), 0);
    }
    uint16_t epsv_port;
    int Recv(const std::string& str) {
        int n = recv(fd, buf, 2000, 0);
        recvbytes += n;
        buf[n] = 0;
        
        int ret = 0;
        if (n >= str.size()) {
            if (memcmp(buf, str.c_str(), str.size()) != 0)
                ret = -1;
        } else
            ret = -1;
//        if (ret != 0)
//            printf("Recv() expect %s got %s", str.c_str(), buf);
//        printf("recv ret=%d %s\n", ret,buf);
        if (str == "229") {
            for (int i = 0; i < n; ++i)
                if (buf[i] < '0' || buf[i] > '9')
                    buf[i] = ' ';
            int t1, t2;
            sscanf(buf, "%d %d", &t1, &t2);
            epsv_port = (uint16_t)t2;
        }
        return ret;
    }
    int Recv_End(const std::string& str) {
        int n = recv(fd, buf, 2000, 0);
        recvbytes += n;
        buf[n] = 0;
        
        int ret = 0;
        if (n >= str.size()) {
            if (memcmp(buf + n - str.size(), str.c_str(), str.size()) != 0)
                ret = -1;
        } else
            ret = -1;
//        if (ret != 0)
//            printf("Recv_End() expect %s got %s", str.c_str(), buf);
//        printf("recv ret=%d %s\n", ret,buf);
        return ret;
    }
    
    int Recv_Data() {
        int n = recv(newdatafd, buf, BUF_LEN, 0);
        recvbytes += n;
        
//        printf("recv data n=%d \n", n);
        return n;
    }
    
    int Connect(uint16_t port) {
        int fd = socket(AF_INET6, SOCK_STREAM, 0);
        if (fd <= 0)  {
            perror("error in socket() #9");
            exit(0);
        }
        struct sockaddr_in6 serv_addr;
        memset((char *) &serv_addr, 0, sizeof(serv_addr));
        serv_addr.sin6_family = AF_INET6;
        serv_addr.sin6_port = htons(port);
        serv_addr.sin6_addr = serverip.getIn6Addr();
        if (connect(fd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
            perror("ERROR connecting");
            exit(0);
        }
        return fd;
    }
    
    void run__() {
        static int _pid = 0;
        int pid = _pid++;
        //cout << "Run tid " << pid << endl;
        t1 = time();
        
        fd = socket(PF_INET6, SOCK_STREAM, 0);
        if (fd <= 0) {
            perror("error in socket() #86");
            exit(0);
        }
        struct sockaddr_in6 serv_addr;
        memset((char *) &serv_addr, 0, sizeof(serv_addr));
        serv_addr.sin6_family = AF_INET6;
        serv_addr.sin6_port = htons(21);
        serv_addr.sin6_addr = serverip.getIn6Addr();
        if (connect(fd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
            perror("ERROR connecting");
            exit(0);
        }
        Recv("220");
        Send("USER anonymous\r\n");
        Recv("331");
        Send("PASS anon@localhost\r\n");
        Recv("230");
        Send("SYST\r\n");
        Recv("215");

        Send("OPTS UTF8 ON\r\n");
        Recv("200");
        struct timeval t1_pwd;
        gettimeofday(&t1_pwd, NULL);
        Send("PWD\r\n");
        Recv("257");
        struct timeval t2_pwd;
        gettimeofday(&t2_pwd, NULL);
        time_pwd = gettime(t1_pwd, t2_pwd);;
        Send("TYPE I\r\n");
        Recv("200");
        struct timeval t1_eprt;
        if (active) {
        
            datafd = socket(AF_INET6, SOCK_STREAM, 0);
            if (datafd <= 0)  {
                perror("error in socket() #118");
                exit(0);
            }
            bzero((char *) &serv_addr, sizeof(serv_addr));
            serv_addr.sin6_family = AF_INET6;
            serv_addr.sin6_addr = in6addr_any;
    //        serv_addr.sin6_port = htons(portno);
            if (bind(datafd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) != 0)  {
                perror("error in bind()");
                exit(0);
            }
            struct sockaddr_in6 sin;
            socklen_t len = sizeof(sin);
            IPv6Addr myaddr;
            uint16_t port;
            if (getsockname(fd, (struct sockaddr *)&sin, &len) == -1) {
                perror("getsockname");
                exit(0);
            } else {
                myaddr = IPv6Addr(sin.sin6_addr);
            }

            if (getsockname(datafd, (struct sockaddr *)&sin, &len) == -1) {
                perror("getsockname");
                exit(0);
            } else {
                port = ntohs(sin.sin6_port);
            }
            sprintf(bufs, "EPRT |2|%s|%d|\r\n", myaddr.getString().c_str(), port);
            gettimeofday(&t1_eprt, NULL);
            Send(bufs);
            Recv("200");
        } else {
            gettimeofday(&t1_eprt, NULL);
            Send("EPSV");
            Recv("229");
        }
        
        struct timeval t2_eprt;
        gettimeofday(&t2_eprt, NULL);
        time_eprt = gettime(t1_eprt, t2_eprt);;

        if (DATA) {

            //data
            if (active) {
                if (listen(datafd, 1) != 0)  {
                    perror("error in listen()");
                    exit(0);
                }
            }
            
            Send("RETR " + SIZE + ".bin\r\n");
            
            if (active) {
                struct sockaddr_in6 cli_addr;
                socklen_t clilen = sizeof(cli_addr);
                newdatafd = accept(datafd, (struct sockaddr *) &cli_addr, &clilen);
            } else {
                newdatafd = Connect(epsv_port);
            }
            Recv("150");
            do {
                if (Recv_Data() <= 0)
                    break;
            } while (1);
            close(newdatafd);
            Recv("226");
        }

        shutdown(fd, SHUT_RDWR);
        close(fd);
        if (active) {
            close(datafd);
        }
        
        
        t2 = time();
        //cout << "End tid " << pid << endl;
        done = true;
//        cout << (t2 - t1) / 1000 << "us" << endl;
    }
    static long long time() {
        struct timespec t;
        memset(&t, 0, sizeof(t));
        clock_gettime(CLOCK_REALTIME, &t);
        return t.tv_sec * 1000000000 + t.tv_nsec;
    }
//private:
    IPv6Addr serverip;
    pthread_t tid;
    int fd;
    bool done;
    int datafd;
    int newdatafd;
    char bufs[2000];
    char buf[BUF_LEN];
    long long t1;
    long long t2;
    
    long long sendbytes;
    long long recvbytes;
    long long time_eprt;
    long long time_pwd;
};
