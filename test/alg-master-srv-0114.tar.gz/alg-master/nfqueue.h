#pragma once

int nfqueue_init();
void nfqueue_handle(char *buf, int len);
void nfqueue_close();

